Sakthi Murugan K - Portfolio
============================

Ellaa files um SAME folder la irukkanum (GitHub la ellaathayum upload pannunga):

  index.html
  hero.png   (unga photo - home section)
  about.jpg  (About section image)

Unga own files (ithu inga illa, neenga add pannanum / repo la already irundha appdiye vidunga):
  Sakthi murugan resume - Copy.pdf
  SAKTHI MURUGAN K (2).pdf
  Thiranex_Certificate_SAKTHI_MURUGAN_K_THX-JUN1426-399.pdf
  DocScanner Sep 13, 2026 2-45 PM.jpg - Copy.jpeg

Links replace panna vendiyavai (index.html la Ctrl+F pannunga):
  PASTE_BUS_PROTOTYPE_LINK_HERE
  PASTE_FINANCE_FIGMA_LINK_HERE
  PASTE_FINANCE_PROTOTYPE_LINK_HERE
  PASTE_SAVINGS_FIGMA_LINK_HERE
  PASTE_SAVINGS_PROTOTYPE_LINK_HERE
